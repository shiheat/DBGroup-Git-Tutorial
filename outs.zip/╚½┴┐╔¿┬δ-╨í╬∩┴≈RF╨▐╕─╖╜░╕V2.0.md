# 一、小物流RF增加扫器械唯一码的功能

1、批发ERP：RF入库单据查询接口修改

接口地址:/inca/rf2erp/instock/query:

请求报文增加字段“来源单号类型”：

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>OrderTyp e購</td><td> string</td><td>10</td><td>是</td><td>来源单号类 型</td><td>0验收单/1合 并验收单/2拣 选单</td></tr></table></body></html>

返回报文LIST增加5个字段：“是否扫药监码”、“是否扫器械码”、“来源单据ID（验收单细单ID/合并验收单细单ID）”、“仓库ID"、“批号ID"

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>Dzjgm bz</td><td> string</td><td>1</td><td>是</td><td>是否扫药监码</td><td>0不扫码、1扫 码</td></tr><tr><td>2</td><td>Qxwym bz</td><td>string</td><td>1</td><td>是</td><td>是否扫器械码</td><td>0不扫码、1扫 码</td></tr><tr><td>3</td><td>SourcN o</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>验收单细单 ID/ 合并验收单细单 ID</td></tr></table></body></html>

<html><body><table><tr><td>4</td><td>StockId</td><td> string</td><td>10</td><td>是</td><td>仓库ID</td><td></td></tr><tr><td>5</td><td>LotId</td><td>string</td><td>100</td><td>是</td><td>批号ID</td><td></td></tr></table></body></html>

# 2、RF：入库单据查询界面修改：

"收货单ID"改为下拉框，选项值有2项：验收单ID、合并验收单ID, 默认收货单ID;

当下拉选择“验收单ID"时，请求报文“来源单号类型”字段传0；当下拉选择“合并验收单ID"时，请求报文“来源单号类型”字段传1。

![](images/b6729c22221327c5ba5cfec32d94f5d804b2618cb46e1e895448ea6dd7763d87.jpg)

# 3、批发ERP：RF出库单据查询接口修改

接口地址：/inca/rf2erp/outstock/query

返回报文LIST增加5个字段：“是否扫药监码”、“是否扫器械码”“来源单据ID（拣选单细单ID）”、“仓库ID"、“批号ID"

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>Dzjgm bz</td><td>string</td><td>1</td><td>是</td><td>是否扫药监码</td><td>0不扫码、1扫 码</td></tr><tr><td>2</td><td>Qxwym bz</td><td>string</td><td>1</td><td>是</td><td>是否扫器械码</td><td>0不扫码、1扫 码</td></tr></table></body></html>

<html><body><table><tr><td>3</td><td>SourcN o</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>拣选单细单ID</td></tr><tr><td>4</td><td>StockId</td><td> string</td><td>10</td><td>是</td><td>仓库ID</td><td></td></tr><tr><td>5</td><td>LotId</td><td>string</td><td>100</td><td>是</td><td>批号ID</td><td></td></tr></table></body></html>

# 4、RF：修改“扫描药监码” 界面：

当“是否扫药监码”为1时，界面不变；

当“是否扫药监码”为0时，“是否扫器械码”为1时，界面标题改为“扫描器械唯一码”，扫码输入框名称改为“器械唯一码”。

当单据数量Quantity/大包装件比BigpackageNum，能整除，界面“扫描包装”默认为“大”，“包装数”显示为大包装件比BigpackageNum;

当“扫描包装”下拉选择“中”时，“包装数”显示为接口返回的中包装件比MidpackageNum;

RF扫码界面增加万能码处理逻辑：

当扫入条码为20个9时，则这个码的“数量”为任务单数量-已扫数量，并扫码完成调用批发“RF扫码结果反馈”接口提交扫描。

![](images/de1982261b11a2c3fb77fa2884a8ac0af80603cf8da1fcbea746a626d78a3008.jpg)

# 二、小物流RF药监码本地化

RF扫码记录不直接写药监码系统，改为保存在英克批发，再由英克批发定时器传到药监码系统。

# 1、批发ERP：数据库新增“扫描记录临时表

增加“扫描记录临时表”，字段如下：

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>OwnerId</td><td> string</td><td>10</td><td>是</td><td>独立单元ID</td><td></td></tr><tr><td>2</td><td>OrderType</td><td>string</td><td>1</td><td>是</td><td>来源单号类 型</td><td>0验收单/1合 并验收单/2</td></tr></table></body></html>

<html><body><table><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>拣选单</td></tr><tr><td>3</td><td>SourcNo</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>验收单细单 ID/合并验收 单细单ID/拣 选单细单ID</td></tr><tr><td>4</td><td>Sku</td><td> string</td><td>20</td><td>是</td><td>SKU</td><td></td></tr><tr><td>5</td><td>LotId</td><td> string</td><td>100</td><td>是</td><td>批号ID</td><td></td></tr><tr><td>6</td><td>BarCode</td><td>string</td><td>256</td><td>是</td><td>码</td><td></td></tr><tr><td>7</td><td>PackageSiz e</td><td>number</td><td></td><td>是</td><td>包装大小</td><td></td></tr><tr><td>8</td><td>Package</td><td> string</td><td>10</td><td>是</td><td>包装类型</td><td></td></tr><tr><td>9</td><td>UserId</td><td> string</td><td>100</td><td>否</td><td>扫码人ID</td><td></td></tr><tr><td>10</td><td>ScanTime</td><td>datetime</td><td></td><td>否</td><td>扫码时间</td><td></td></tr></table></body></html>

# 2、批发ERP：新增“保存临时扫码记录”接口

请求报文同“RF扫码结果反馈”接口的请求报文（第5点），

接口功能：将请求数据写入“扫描记录临时表

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段描述</td><td>取值逻辑</td></tr><tr><td>1</td><td>OwnerId</td><td>独立单元ID</td><td>LIST的Owner转换为独立单元ID</td></tr><tr><td>2</td><td>SourcNo</td><td>来源单ID</td><td>LIST的来源单据ID</td></tr><tr><td>3</td><td>OrderType</td><td>来源单号类型</td><td>LIST的来源单号类型</td></tr></table></body></html>

<html><body><table><tr><td>4</td><td>Sku</td><td>SKU</td><td>LIST的 SKU</td></tr><tr><td>5</td><td>LotId</td><td>批号ID</td><td>LIST的批号ID</td></tr><tr><td>6</td><td>BarCode</td><td>码</td><td>CHILD_TABLE_LIST的条码</td></tr><tr><td>7</td><td>PackageSize</td><td>包装类型</td><td>CHILD_TABLE_LIST的包装类型</td></tr><tr><td>8</td><td>Package</td><td>包装大小</td><td>CHILD_TABLE_LIST的包装大小</td></tr><tr><td>9</td><td>UserId</td><td>扫码人ID</td><td>CHILD_TABLE_LIST的采集人账号</td></tr><tr><td>10</td><td>ScanTime</td><td>扫描时间</td><td>CHILD_TABLE_LIST的采集时间</td></tr></table></body></html>

# 3、批发ERP：新增“查询临时扫码记录”接口

请求报文字段： （按ESB报文规则）：其中LIST字段如下：  

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>OrderType</td><td>string</td><td>1</td><td>是</td><td>来源单号类 型</td><td>0验收单/1合 并验收单/2 拣选单</td></tr><tr><td>2</td><td>SourcNo</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>验收单细单 ID/合并验收 单细单ID/拣 选单细单ID</td></tr><tr><td>3</td><td>Sku</td><td>string</td><td>20</td><td>是</td><td>SKU</td><td></td></tr><tr><td>4</td><td>Lotid</td><td>string</td><td>100</td><td>是</td><td>批号ID</td><td></td></tr></table></body></html>

接口处理：按请求报文查询“扫描记录临时表

返回报文字段：LIST字段如下：

<html><body><table><tr><td></td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>序号 1</td><td>OrderType</td><td> string</td><td>1</td><td>是</td><td>来源单号类 型</td><td>0验收单/1合 并验收单/2 拣选单</td></tr><tr><td>2</td><td>SourcNo</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>验收单细单 ID/合并验收 单细单ID/拣 选单细单ID</td></tr><tr><td>3</td><td>Sku</td><td>string</td><td>20</td><td>是</td><td>SKU</td><td></td></tr><tr><td>4</td><td>LotId</td><td>string</td><td>100</td><td>是</td><td>批号ID</td><td></td></tr><tr><td>6</td><td>BarCode</td><td> string</td><td>256</td><td>是</td><td>码</td><td></td></tr><tr><td>7</td><td>PackageSiz e</td><td>number</td><td></td><td>是</td><td>包装大小</td><td></td></tr><tr><td>8</td><td>Package</td><td> string</td><td>10</td><td>是</td><td>包装类型</td><td></td></tr></table></body></html>

# 4、RF：进入扫码界面逻辑修改：

按以下逻辑组织请求报文：

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类 型</td><td>字段 长度</td><td>是否 必填</td><td>字段描述</td><td>取值逻辑</td></tr><tr><td>1</td><td>OrderTyp</td><td> string</td><td>1</td><td>是</td><td>来源单号类</td><td>入库扫码：下拉选择“收</td></tr></table></body></html>

<html><body><table><tr><td></td><td>e</td><td></td><td></td><td></td><td>型</td><td>货单ID"时，传O；下拉选 择“合并验收单ID"时， 传1； 出库扫码：传2</td></tr><tr><td>2</td><td>SourcNo</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>查询接口返的 SourcNo</td></tr><tr><td>3</td><td>Sku</td><td> string</td><td>20</td><td>是</td><td>SKU</td><td>界面所选细单的 SKU</td></tr><tr><td>4</td><td>Lotid</td><td>string</td><td>100</td><td>是</td><td>批号ID</td><td>界面所选细单的Lotid</td></tr></table></body></html>

调用“查询临时扫描记录”接口，将返回的扫码记录显示在条码列表中。

界面列与报文字段对应："条码”-码、“类型”-包装类型、"数量”-包装大小。

# 5、RF：扫码完成自动提交修改：

不保存药监码数据库

》调整“RF扫码结果反馈接口”的请求报文：将所扫的药监码放在请求报文里面一起给批发系统，LIST增加字段：

<html><body><table><tr><td>序 号</td><td>字段名</td><td>字段类 型</td><td>字段是否 长度必填</td><td></td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>InOutType</td><td>string</td><td>10是</td><td></td><td>出入库类型</td><td>取扫码界面的入库类型 或出库类型，见图2</td></tr></table></body></html>

<html><body><table><tr><td>2</td><td>OrderType</td><td> string</td><td>1</td><td>是</td><td>型</td><td>来源单号类|0验收单/1合并验收 单/2拣选单</td></tr><tr><td>3</td><td>SourcNo</td><td>string</td><td>100</td><td>是</td><td>来源单据ID</td><td>验收单细单 ID/合并验 收单细单ID/拣选单细 单ID</td></tr><tr><td>5</td><td>Lotid</td><td>string string</td><td>100 256</td><td>是 是</td><td>批号ID 仓库ID</td><td></td></tr><tr><td>6 7</td><td>StockID Supplier</td><td>numb er</td><td></td><td>是</td><td>供应商编码 或客户编码</td><td></td></tr><tr><td>8</td><td>OperationType</td><td>string</td><td>10是</td><td></td><td>操作类型</td><td>采购入库传1-进货，销 退入库传4-销退，移库 入库传5-移入，销售出 库传3-销售，进退出库 传2-进退，移库出库传 6-移出</td></tr><tr><td>9</td><td>barcodeType</td><td>string</td><td>100否</td><td></td><td>条码类型</td><td>当扫码框名称为“药监 码”时，传“药监 码”，当扫码框名称为 “器械唯一码”时，传</td></tr><tr><td>10</td><td>Remark</td><td>dateti</td><td></td><td>否</td><td>备注</td><td>“器械唯一码” 传“RF采码”</td></tr></table></body></html>

<html><body><table><tr><td></td><td></td><td>me</td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>CHILD_TABLE_LI ST</td><td>list</td><td></td><td>是</td><td>药监码数组</td><td></td></tr></table></body></html>

CHILD_TABLE_LIST明细字段如下：

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段 长度</td><td>是否 必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>Scantime</td><td>Datetim e</td><td></td><td>否</td><td>采集时间</td><td>传当前时间</td></tr><tr><td>2</td><td>barcode</td><td>string</td><td>100</td><td>否</td><td>码</td><td>传扫码界面列表的 条码</td></tr><tr><td>3</td><td>packagesiz e</td><td>string</td><td>100</td><td>否</td><td>包装大小</td><td>传扫码界面包装数</td></tr><tr><td>4</td><td>package</td><td>string</td><td>10</td><td></td><td>包装类型</td><td>传扫码界面扫描包 装下拉框的值</td></tr><tr><td>5</td><td>Userid</td><td>string</td><td>32</td><td></td><td>采集人账号</td><td></td></tr></table></body></html>

# 入库

![](images/df66d2b50e89812bf880bfcf75e86f2a15a81d91cc29168c88cc164714989513.jpg)  
图2

# 6、RF：临时保存按钮功能修改：

调用“临时保存扫码记录”接口，将临时扫码记录保存到批发系统中，请求报文同“RF扫码结果反馈接口”。

# 7、批发ERP：RF扫码结果反馈接口改造：

接口地址:/inca/rf2erp/scanfeedback修改单据的状态逻辑：当“来源单号类型”为0验收单或2拣选单时，逻辑不变，当为1合并验收单时，将验收合并结果明细表中对应数据行的“药监码扫码”字段更新为1，同时将该合单对应的验收单明细上的“药监码扫码”字段更新为1。若验收单明细已产生出入库明细数据，还需将出入库明细上的“药监码扫码”字段更新为1。

删除“扫描记录临时表”对应的数据，按“来源单据 ${ \mathrm { I D } } +$ 来源单号类型$+ 5 \mathsf { K } \mathsf { U } +$ 批号ID"维度进行删除。

新增写药监码或器械唯一码到批发系统数据库的处理逻辑：

ZX_YJM_INFO药监码、ERP_EQUIPCODE_STIO唯一码出入库记录 增加字段:

<html><body><table><tr><td>序号</td><td>字段名</td><td>字段类型</td><td>字段长度</td><td>是否必填</td><td>字段描述</td><td>备注</td></tr><tr><td>1</td><td>OrderType</td><td>string</td><td>10</td><td>是</td><td>来源单号类 型</td><td>0收货单/1合 并验收单/2 拣选单</td></tr></table></body></html>

$\downarrow$ 若请求的“条码类型”为“药监码”，则将数据写入【6050药监码查询】界面中，药监码ZX_YJM_INFO字段处理逻辑如下:

<html><body><table><tr><td>字段名</td><td>字段含义</td><td>取值逻辑</td></tr><tr><td>sourceid</td><td>来源ID</td><td>LIST的来源单据ID</td></tr><tr><td>OrderType</td><td>来源单号类型</td><td>LIST的来源单号类型</td></tr><tr><td>comefrom</td><td>来源类型</td><td>LIST的操作类型</td></tr><tr><td>inouttype</td><td>出入库类型</td><td>LIST的出入库类型</td></tr><tr><td>goodsid</td><td>货品ID</td><td>LIST 的 SKU</td></tr><tr><td>goodsdtlid</td><td>货品明细ID</td><td>ERP自行根据LIST的“来源单据 ID"+"来源单据类型”去找货品明细 ID</td></tr></table></body></html>

<html><body><table><tr><td>lotid</td><td>批号ID</td><td>LIST的批号ID</td></tr><tr><td>companyid</td><td>相关单位ID</td><td>ERP 自行根据LIST的供应商编码或 客户编码转换为供应商ID或客户 ID</td></tr><tr><td>storerid</td><td>仓库ID</td><td>LIST 的仓库ID</td></tr><tr><td>memo</td><td>备注</td><td>LIST的备注</td></tr><tr><td>inputmanid</td><td>采集人ID</td><td>根据CHILD_TABLE_LIST的采集人</td></tr><tr><td>entryid</td><td>独立单元ID</td><td>账号转换为人员ID LIST的Owner转换为独立单元ID</td></tr><tr><td>credate</td><td>采集时间</td><td>CHILD_TABLE_LIST的采集时间</td></tr><tr><td>yjm yjm_packtyp</td><td>药监码 药监码包装类</td><td>CHILD_TABLE_LIST的码 CHILD_TABLE_LIST的包装类型</td></tr><tr><td>e yjm_packsize</td><td>型 药监码包装大</td><td>CHILD_TABLE_LIST的包装大小</td></tr><tr><td>iodtlid</td><td>小 出入库细单ID</td><td>LIST的出入库细单 ID</td></tr><tr><td>oridocid</td><td>原总单ID</td><td>ERP自行根据LIST的“来源单据 ID"+"来源单据类型”找入库订单或</td></tr><tr><td>oridtlid</td><td>原细单ID</td><td>出库订单的总单ID 若“来源单据类型”为“1-合并验 收单”则存空，否则 ERP 自行根据</td></tr></table></body></html>

<html><body><table><tr><td></td><td></td><td>LIST的“来源单据ID"+"来源单据 类型”找入库订单或出库订单的细 单ID</td></tr></table></body></html>

若请求的“条码类型”为“器械唯一码”，则将数据写入【541702唯一码出入库记录查询】界面中，器械唯一码ERP_EQUIPCODE_STIO字段处理逻辑如下:

<html><body><table><tr><td>字段名</td><td>字段描述</td><td>取值逻辑</td></tr><tr><td>sourceid</td><td>来源ID</td><td>LIST来源单据ID</td></tr><tr><td>OrderType</td><td>来源单号类型</td><td>LIST的来源单号类型</td></tr><tr><td>operationtype</td><td>业务类型</td><td>LIST的出入库标志</td></tr><tr><td>goodsid</td><td>货品ID</td><td>LIST 的 SKU</td></tr><tr><td>lotid</td><td>批号ID</td><td>LIST的批号ID</td></tr><tr><td>lotno</td><td>批号</td><td>LIST的批号</td></tr><tr><td>proddate</td><td>生产日期</td><td>ERP自行根据LIST的批号ID找 生产日期</td></tr><tr><td>validdate</td><td>有效期</td><td>ERP自行根据LIST的批号ID找 有效期期</td></tr><tr><td>companyid</td><td>出入单位ID</td><td>ERP自行根据LIST的供应商编码 或客户编码转换为供应商ID 或客 户ID</td></tr><tr><td>storerid</td><td>仓库ID</td><td>LIST的仓库ID</td></tr></table></body></html>

<html><body><table><tr><td>memo</td><td>备注</td><td>LIST的备注</td></tr><tr><td>entryid</td><td>独立单元ID</td><td>LIST的Owner转换为独立单元 ID</td></tr><tr><td>credate</td><td>制单日期</td><td>CHILD_TABLE_LIST的采集时间</td></tr><tr><td>uniquecode</td><td>唯一码</td><td>CHILD_TABLE_LIST的码</td></tr><tr><td>qty</td><td>数量</td><td>CHILD_TABLE_LIST的包装大小</td></tr><tr><td>srcdtlid</td><td>来源单号</td><td>LIST的出入库细单ID</td></tr></table></body></html>

调药监码写入接口，将扫码记录同步到药监码系统。