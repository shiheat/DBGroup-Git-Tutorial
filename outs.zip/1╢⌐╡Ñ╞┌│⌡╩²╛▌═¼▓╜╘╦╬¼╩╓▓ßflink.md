# 订单期初数据同步步骤

1、打开 dinky: http://inca-zt-dinky.cq-p.com.cn:8090/#/datastudio点击折叠目录，打开【订单初始化贴源】，此文件夹下的任务皆属于订单期初数据同步的任务。如图：

↑ Q A不安全|inca-zt-dinky.cq-p.com.cn:8090/#/datastudio 8 a A" ★ + 中 ☆ □  
work浑身知识点 环境配置 工具 中台prom work1统一入口 重药运维 讯飞ADinky实时计算平台 数据开发 运维中心 器注册中心 系统设置 关于 Q ? Admin 文A折叠目录  
® 引 贝 ®  
目暴录 回 欢迎使用Dinkyv0.6.6 快捷引导rch Q ○注册集群实例实时即未来，Dinky为ApacheFlink而生，让FlinkSQL纵享丝滑，并致力于实时计算平台建设。  
画结构 V 贴源 ○注册集群配置批发 快捷键 注册Jar。注册数据源  
会话 品集群 贴源 >□两票kafka 美 T进 更保存 Ctr1+F搜索 Alt+2校验 Ctr1+H替换 选中+Shift+Tab取消缩进 Alt+3美化 Ctr1+2撤销 Shift+Alt+Right选中后续 F2全屏 Ctr1+Y重做 Esc关闭弹框及全屏 Ctr1+/注释 Shift + F1 。注配置 ○Github ○官网文档订单初始化贴源  
目数据源 Ctr1+Shift+Up/Down编辑多行 Shift+Alt+Up/Down复制一行 Ctr1+Shift+K删除批发qczt_basic_contact_goods表同步 一行批发qczt_basic_contact_info表同步  
… 批发cy 前上一个匹配下一个 Ctr1+Shift+F3匹配上一个 F7前往下一个高亮 Shift +F7信息 结果 BI 品血缘 进程 历史 f函数暂无数据↑ C 不安全|inca-zt-dinky.cq-p.com.cn:8o90/#/datastudio P a动 A ★ 中 中 ☆ . □  
work浑身知识点环境配置 中台promwork1统一入口重药运维 讯飞AIDinky实时计算平台 数据开发 运维中心 品注册中心 系统设置 关于 Q ? Admin 文A  
③贴源/批发/订单初始化贴源/批发qczt_basic_contact_goods表同步 口回 日凹⊙ 4 回②  
三目录 山山 批tgb 批gqtbi corsc 点击即可启动任务 日 作业配置Q 执行模式  
画结构 V 贴源 1415 )WITHonnecto 福 Kubernetes Sessionoracie-cdcv批发 16 hostname 172.31.10.145 定 Flink集群 心  
会话 > □库存贴源 1718 portname 1521' ubemetes-session本地-订单-oms 执行配置> AA □两票贴源 □两票kafka 39 28212232425257 password base 1-HPF FinksQl裴示该任务所运行的集群地址CQY 无 保存点  
品集群 > □货品分类 CZT□库存贴源Kafka de online 任务并行度 Insert语句集>debe minin S.mine' ='tru 用V 订单初始化贴源 debezium.log.mining.batch.size.max'='10000 1  
目数据源 b 728 debeziun.lggee .time e.case. incremen .insensitive 300fa1s 全量 批模式① 版本历中）; 禁用批发qczt_company_to_contact表同步 29 CREATETABLEQCZT_BASIC_CONTACT_GOODS_SINK(  
… 批发qczt_cyqd_batch_custom_lst表同步 30 IDSTRING,TAGT SavePoint策略 …·信息 结果 Bl 品血缘 $\boxed { \pm }$ 进程 历史 函数  
2 回 凸 ? 西 ? 回 口 -D ③运行状态 日停止执行模式③ 1

2、找到对应任务，点击右上角小火煎即可运行任务。

3、根据表数据量大小，当任务运行1-5分钟后，打开ERP数据库和PG数据库，通过selectcount(\*)from 表，对比两边数据量是否一致，当数据一致后，说明数据同步完毕。

发/订单初始化贴源/批发qczt_basic_contact_info表同步 日 回 白 日 P ? 回 口  
山山 批发qczt_basic_contact_info表同步X 批发qczt_company_to_contact表同Q 28 SEQID DECIMAL(12,0), 执行模式③  
订单初始化贴源 29 PRIMARYKEY(SEQID) NOT ENFORCED Kubernetes Session批发qczt_basic_contact_goods表同步 30311 )WITHnector 'oracle-cdc 数据源信息 Flink集群3233435 [e批发qczt_cydatchchanneltactic 3637 databasenae 无批发gqczcydodschaneacic表同 38 table-nam 'QCZT_BASIC_CONTACT_INFO 任务并行度 Insert语句集①3948 debezi批发gqcz_cyqdgodsst表同步 1 禁用4142 debezium.database.tablena sensitive 全局变量 批模式①）；43 CREATETABLEQCZT_BASIC_CONTACT_INFO_SINK（ 禁用 禁用批发qczt_customer_class表同步 44 ID STRING,批发qczt_customer_classdt同步 45 CONTACT_NAME STRING, SavePoint策略ONT COnr CTOTA结果 BI 品血缘 进程 历史 f函数PG数据库信息Dinky实时计算平台 数据开发 运维中心 器注册中心 系统设置 关于 Q ? Admin 文  
③ 贴源/批发/订单初始化贴源/批发qczt_basic_contact_goods表同步 过 回 日 O 9 回 □ 00 ?  
目录 大备库存批发集群 tgtbc 批tctbs.cractt 执行模式 □ 愈作业配置  
画结构 灾备票证SCM集群 订单贴源集群 1516 17 14 )WIT.coceoco port '1521' 172.31.10.145 匡 F kube sessio 执行配置  
0 18 username RACAF kubermetes-session 本地-订单-oms本地-订单贴源集群 19202122 Dassse pt1-HPF FlinkSQL环境③本地-订单-oms 无 保存点  
品  
集群 本地-灾备-oms 23 log.minin ategy catalog 任务并行度 Insert语句集24 debe .mini ontin mine  
目数据源 库存贴源集集群 252627 28 ）； 全局变量 禁用 禁用 版本历中  
... <1 29 30 CREATE TABLEQCZT_BASIC_CONTACT_GOODS_SINK( ID STRING, SavePoint策略 ..COMDANV CONTAGT信息 结果 Bl 品血缘 进程 历史 f函数

右侧显示该任务在集群：【本地-订单-oms】，点击本图中左侧【集群】，分页查找该集群名称，点击可查看集群详情

Dinky实时计算平台 数据开发 运维中心 品注册中心 系统设置 关于本地-订单-oms 配置 删除  
③ 贴源/批发/订单初始化贴源/批发qczt_basic_contact_goods表同步  
三 库存批发集群 t 批发qczt 集:6名：本地订单-oms 唯一标：本地定单-m  
目县  
结构 灾备票证SCM集群 14 151517 )WITH（ otoe Job 当前ageinca订单贴源集群 port\*\*=1521\*, oms.cq-p.com.cn:80 oms.cq-  
会话 1819 userna 'ORACI 复制该地址，浏览器打开即可查看该集群的任务本地-订单贴源集群 "oracapt1_HPFP20 database-nase'=:ERPcB', 版本：1.13.6 状态：正常本地-订单-oms 21223242526272829 schena-name 'CQYYPROD  
吊 table-naMe'=QCZT_BASIC_CONTACT_G0O0 注释： 是否启用：·已启用  
集 本地-灾备-oms debezium.log.mining.strategy.-'online  
群 debezium.log,mining.continuous.mine' 注册方式：·手动 集群配置ID：-库存贴源集群 debezium.log.mining.batch.size.max'=  
目 debezium.log.mining:sleep.time.increm 作业ID：- 创建时间：2024-04-2921:44:58  
数据源 出站规则任务集群 ebezium.database.tablename.case.inse）; 最近更新时间：2024-05-0715:33:141② 30 CREATETABLECACONTA

![](images/d3b088fc576db609e245030e3955067b54b18b4e100ba85044ee6ec07fe2586f.jpg)  
点击Job Name可查看指定任务的运行日志，如：点击PG_pf_bms_st_io_dtl_2

![](images/edd49b13a2bb5fd67519bf1404f75e9950ffdd0eb45ba4335436341099e97b93.jpg)

akka.tcp://flink@172.18.2.93:6122/user/rpc/taskmanager_0   

<html><body><table><tr><td rowspan="2"></td><td colspan="2">LastHeartbeat:2024-07-1815:24:40</td><td colspan="4">ID:flink-stocksource-taskmanager-1-4 Data Port:46726</td><td rowspan="2"></td><td rowspan="2">FreeSlots/AllSlots:0/8</td><td rowspan="2">CPU Cores:2</td></tr><tr><td>PhysicalMemory:4.0oGB</td><td></td><td></td><td>JVM HeapSize:1.49GB</td><td></td><td>FlinkManagedMemory:1.34GB</td></tr><tr><td rowspan="2">Metrics</td><td>Logs</td><td rowspan="2">Stdout</td><td rowspan="2">Log List</td><td rowspan="2">Thread Dump</td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td></tr><tr><td>"storaged"1014"ed"6,"sodte":"2415:20:0",tpce":40"su"："",</td></tr><tr><td>23717</td><td colspan="7">"invuplodf，:ec:，:"：， "stioflag":1,"z_fasvariety":0,"sfp":"0","storerid":278,"examprofitrate":0.05000,"salesdtld":68723, "zte:e:瓶dot "t: "spf： "notaxmoey7966edtarti":83858"dabe":"","odtd:414tt:4btd78 "z_spt":7t flag:{} 2024-07-1815:23:02,799ERRORcom.inca.cqyy.saorder.reconcile.pf.bsdtl.sink.RabbitmqSink[]-cpush msg： {"olunp" z_sed:t</td></tr></table></body></html>

如果任务运行异常，可以通过排查运行日志进行分析并处理。

附件 —任务名称

<html><body><table><tr><td>序号</td><td>期初导入任务</td><td>任务名称</td></tr><tr><td>1</td><td>客商组别代码货品明细</td><td>qczt_basic_contact_goods</td></tr><tr><td>2</td><td>组别代码</td><td>qczt_basic_contact_info</td></tr><tr><td>3</td><td>客商组别代码</td><td>qczt_company_to_contact</td></tr><tr><td>4</td><td>客户分类</td><td>qczt_customer_class</td></tr><tr><td>5</td><td>客户分类细单</td><td>qczt_customer_class_dtl</td></tr><tr><td>6</td><td>货品分类</td><td>qczt_goods_class</td></tr><tr><td>7</td><td>货品分类细单</td><td>qczt_goods_class_dtl</td></tr></table></body></html>

<html><body><table><tr><td>8</td><td>供应商分类</td><td>qczt_supply_class</td></tr><tr><td>9</td><td>供应商分类细单</td><td>qczt_supply_class_dtl</td></tr><tr><td>10</td><td>批次渠道策略</td><td>qczt_cyqd_batchchannel_tacti CS</td></tr><tr><td>11</td><td>批次渠道策略客户列表</td><td>qczt_cyqd_batch_custom_lst</td></tr><tr><td>12</td><td>货品渠道策略</td><td>qczt_cyqd_goodschannel_tact ics</td></tr><tr><td>13</td><td>货品渠道策略货品列表</td><td>qczt_cyqd_goods_lst</td></tr><tr><td>14</td><td>货品渠道策略供应商列表</td><td>qczt_cyqd_goods_supply_lst</td></tr><tr><td>15</td><td>货品渠道策略客户列表</td><td>qczt_cyqd_goods_custom_lst</td></tr><tr><td>16</td><td>资信占用表</td><td>qczt_cyzx_sa_dtl</td></tr><tr><td>17</td><td>资信释放</td><td>QCZT_CYZX_SA_REC_DTL qczt_cyzx_entry_creditacc_do</td></tr><tr><td>18</td><td>资信中心-资信账户对应货品维护总单</td><td>C</td></tr><tr><td>19</td><td>资信中心-资信账户对应货品维护细单</td><td>qczt_cyzx_entry_creditacc_dtl</td></tr><tr><td>20</td><td>资信中心-超信免控单据管理</td><td>qczt_cyzx_free_control</td></tr><tr><td>21 22</td><td>资信中心-资信额度、天数汇总表总资 信表 资信中心-资信额度、天数汇总表正式</td><td>qczt_cyzx_credit_days qczt_cyzx_acc_credit_day</td></tr></table></body></html>

<html><body><table><tr><td></td><td>资信表</td><td></td></tr><tr><td>23</td><td>资信中心-资信额度、天数汇总表临时 资信表</td><td>qczt_cyzx_acc_credit_day_tm p</td></tr><tr><td>24</td><td>库存中心 保管账库存</td><td>qczt_cykc_st_qty_lst</td></tr><tr><td>25</td><td>订单中心-停售解除管理</td><td>qczt_cydd_stop_stock</td></tr><tr><td>26</td><td>库存中心 储备计划总单</td><td>qczt_cykc_storeplan_doc</td></tr><tr><td>27</td><td>库存中心 储备计划细单</td><td>qczt_cykc_storeplan_dtl</td></tr></table></body></html>