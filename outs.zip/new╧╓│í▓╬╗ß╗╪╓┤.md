附件

# 现场参会回执

企业名称：X×公司 (请备注总部、南区、北区)

<html><body><table><tr><td>姓名</td><td>职务</td><td>联系电话</td><td>备注</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></table></body></html>

填表人： 联系电话：