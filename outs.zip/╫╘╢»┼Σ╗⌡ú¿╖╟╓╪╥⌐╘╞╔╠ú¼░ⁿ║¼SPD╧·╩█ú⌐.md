<html><body><table><tr><td rowspan="2">项目名称：中台ERP 改造</td><td rowspan="2">方案节点：2.11.2 流程名称：平台订单 (非重药云商订单)</td><td>流程说明：平台订单自动配货</td></tr><tr><td>流程</td></tr></table></body></html>

![](images/a4be003d231bc8f1515ec6f0ead062aeafde3c33f685fd804fb25080094895dc.jpg)