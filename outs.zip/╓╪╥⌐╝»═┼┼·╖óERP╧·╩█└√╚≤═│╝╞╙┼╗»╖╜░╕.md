# 重药集团批发ERP销售利润统计优化方案

# 背景

结合《关于绩效考核成本和销售单据关联配送补贴价功能启用通知》的工作要求，药品销售中心对相关功能进行了梳理和功能使用，在使用过程中该单位提出需要对绩效成本、配送毛利单价取数规则作进一步优化的需要。

# 优化前方案

为减少考核成本维护滞后和价格设置相对保守的情况，提高销售部门考核准确性和指导性，在考核成本价格体系（含售前考核和售后考售）中增加了绩效考核成本和配送毛利单价等价格维度，其在销售报表如“销售明细综合查询（550001）”功能中的取值逻辑如下：

<html><body><table><tr><td rowspan="2">商品名称</td><td rowspan="2">销售数 量/盒</td><td rowspan="2">采购价/销售价/ 元</td><td colspan="4">成本价格取值体系</td><td rowspan="2">配送补 考核成 贴价/元</td><td rowspan="2">绩效成</td><td rowspan="2">配送毛 利单价</td><td rowspan="2">配送毛 利额</td><td rowspan="2">配送毛利 差 -20</td></tr><tr><td>成本优 元 先级</td><td>成本价 格维度</td><td>成本单 价／元</td><td>本价本价</td></tr><tr><td rowspan="4">阿莫西林</td><td>20</td><td>10</td><td>9</td><td>售前考 1核成本 价 售后考</td><td>8</td><td>3</td><td>8</td><td>5</td><td>4</td><td>80</td></tr><tr><td></td><td></td><td></td><td>2核成本</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3</td><td>价 绩效考</td><td>6</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>核成本 价</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table></body></html>

<html><body><table><tr><td></td><td></td><td></td><td></td><td></td><td>售后绩 4效考核 成本价</td><td>5</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>说明</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>配送毛 利单价 =销售 价-考核 成本价 +配送 补贴价</td><td>配送毛 利额=配 送毛利 单价*销 售数量</td><td>配送毛利 差异=配 送毛利 额-绩效 成本价* 销售数量</td></tr></table></body></html>

该方案因配送毛利单价未结合绩效考核成本价，导致查看最终成本价和利润不直观，故对方案作进一步优化。

优化后方案  

<html><body><table><tr><td rowspan="2">商品名称</td><td rowspan="2">销售 数量 /盒</td><td rowspan="2">元</td><td rowspan="2">采购价/销售」成本</td><td colspan="3">成本价格取值体系</td><td rowspan="2">配送 考核成 补贴 本价</td><td rowspan="2">绩效成本价</td><td rowspan="2">绩效毛丨绩效毛 利利率</td><td rowspan="2">配送毛 利成本 价</td><td rowspan="2">配送毛 利单价</td><td rowspan="2">配送毛利 配 额 利</td></tr><tr><td>价/元优先</td><td>成本价格维 度</td></tr><tr><td>阿莫西林</td><td>20</td><td>10</td><td>9</td><td>级 1</td><td>售前考核成 本价</td><td>元 8</td><td>3 8</td><td>5</td><td>4 44%</td><td>2</td><td>7</td><td>140</td></tr><tr><td></td><td></td><td></td><td></td><td>2 3</td><td>售后考核成 本价 绩效考核成</td><td>6</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table></body></html>

<html><body><table><tr><td></td><td></td><td></td><td>4</td><td>售后绩效考 核成本价</td><td></td><td>5</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="6">说明</td><td rowspan="6"></td><td rowspan="6"></td><td rowspan="6"></td><td rowspan="6"></td><td rowspan="6"></td><td rowspan="6"></td><td>成本优先级 绩效毛</td><td>绩效毛</td><td>成本优</td><td>配送毛</td><td>配送毛利</td><td></td></tr><tr><td>从低到高分 利=销</td><td></td><td>利率=先级从</td><td>利单价=</td><td></td><td>额=配送毛</td></tr><tr><td>别是</td><td>售价-绩绩效毛</td><td>低到高</td><td></td><td>销售价-</td><td>利单价*销</td></tr><tr><td>1、2、3、4</td><td>效成本</td><td>利/销</td><td>分别是</td><td>最终绩</td><td>售数量</td></tr><tr><td>个等级</td><td>价</td><td>售价</td><td>1、2、</td><td>效成本</td><td></td></tr><tr><td>因同时维护</td><td>了4个成本</td><td></td><td>3、4个 等级</td><td>价+配送</td><td></td></tr><tr><td rowspan="5"></td><td rowspan="5"></td><td rowspan="5"></td><td></td><td></td><td></td><td></td><td></td><td>补贴价</td><td></td></tr><tr><td></td><td>价系统按最</td><td></td><td>因同时</td><td></td><td></td><td></td></tr><tr><td></td><td>高级别即</td><td></td><td>维护了</td><td></td><td></td><td></td></tr><tr><td></td><td>“售后绩效</td><td></td><td>4个成</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table></body></html>

<html><body><table><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>本价系</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>统按最 高级别</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>考核成本</td><td></td><td></td><td>即“售</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>价”</td><td></td><td></td><td>后绩效</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>考核成</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>本价”</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>取值为</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>5元</td><td></td><td></td><td></td></tr></table></body></html>

如上表所示，在原基础上增加配送成本价，该价格将结合考核成本和绩效成本两个价格体系出具最终的配送成本，以便直观、准确体现经营情况。

英克批发角色：（A）系统管理员 部门：办公室 操作员：（信息中心）管理员 日期：2024-03-27PM-导航（0） $x$ 外部系统管理（80200）×绩效考核成本基础设置（84040）× 售后绩效考核成本维护（84041）×售后考核成本导入（82019）×销售明细综合查询（550001）×+  
新增编辑放弃删除查询 绩效成本模板导出 绩效成本批量导入 保存打印数据分析 界面关闭 独立单元：重庆医药（集团）股份有限公司（2）  
第1/3766条记录，状态：已保存 确认（Ctrl+w） 表格（ESC) 一条（CTRL+J） 下一条（CTRL+K）单据ID2530 维度ID1 维度名称货品 二货品ID1000449679 通用名妇炎康复片 二 规格0.9g\*48s（薄膜衣）供应商 二 客户 二 客户分类 二  
绩效成本...50 生产厂家重庆神奇药业股份有 来货单位ID客户ID 独立单元ID2  
客户分类ID 绩效毛利率

针对部分成本价不固定，但能够确定毛利率的情况，在84040功能中增加绩效毛利率，销售中按绩效毛利率反算绩效考核成本价<公式：销售单价\*（1-绩效毛利率） $> ,$ 绩效成本价与绩效毛利率维护时只能二选1

绩效考核成本维护功能增加成本有效期。

当售前考核成本变更后，自动清空已维护的绩效考核成本，以便于重新定价。

# 操作注意事项：

工作中应避免售前考核成本与配送补贴价格重复计入成本的问题，对于已重复计入的要将对应售前考核成本进行作废。

要及时对售前考核成本进行维护，对于经营过程中的成本错误要及时通过“售后绩效考核成本维护”功能进行修整，对于售后成本错误的单据可一并纳入“售后绩效考核成本维护”功能中处理。