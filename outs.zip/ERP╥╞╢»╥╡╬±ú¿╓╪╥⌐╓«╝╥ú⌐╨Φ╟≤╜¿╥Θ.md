# ERP移动业务需求建议

# 一、客户信息

1、客户资信信息，需增加独立单元名称、当前欠款天数、当前欠款金额、临时额度、临时天数、总额度、总天数等资信信息。并包含回款未认领金额及预收款余额。

![](images/9dfa6ab7f2fa30aee88c7b2cd6747bb44f73df0e1f3d0cc3d3574aaa03c46463.jpg)

# 2、回款信息。

需根据客户信息的独立单元进行查询，否则多家公司不好区分；查询条件的时间段选择后，并不能查询到之前的回款信息；增加筛选条件：认领完成、未认领、回退认领

![](images/50415cd85184f7e50972e2accf871c6d661dda6c00ac1edafb81bdf0710a8386.jpg)

# 二、库存查询

库存查询总单与细单都增加库存数量、停售数量的显示

<html><body><table><tr><td>商品名称/编码 阿莫西林</td><td colspan="3"></td></tr><tr><td>分公司</td><td colspan="3">贵州省医药(集团)和平医药有限公司</td></tr><tr><td>生产厂家</td><td colspan="3">请输入生产厂家</td></tr><tr><td></td><td colspan="3">重置</td></tr><tr><td colspan="3">查询</td><td></td></tr><tr><td colspan="3">阿莫西林克拉维酸钾颗粒</td><td></td></tr><tr><td colspan="3">商品编码 40010100270504</td><td></td></tr><tr><td colspan="3">规格 156.25mg*12袋(4:1)</td><td></td></tr><tr><td colspan="3">生产厂家 葵花得菲尔</td><td></td></tr><tr><td colspan="3">分公司 贵州省医药(集团）和平医药有限公司</td><td></td></tr><tr><td colspan="3">可调库存 2350</td><td></td></tr><tr><td colspan="3">零售价 10.68</td><td></td></tr><tr><td colspan="3">采购员 方颖</td><td></td></tr><tr><td colspan="3">阿莫西林克拉维酸钾颗粒</td><td></td></tr><tr><td colspan="3">商品编码 40010100270804</td><td></td></tr><tr><td colspan="3">规格 0.15625g*12包</td><td></td></tr><tr><td colspan="3">生产厂家 石家庄中诺 分公司 贵州省医药(集团)和平医药有限公司</td><td></td></tr><tr><td colspan="3">可国库友 160</td><td></td></tr><tr><td colspan="3">阿莫西林克拉维酸钾颗粒</td><td></td></tr><tr><td colspan="3">商品编码：40010100270504</td><td></td></tr><tr><td colspan="3">失效日期：2025-09-30</td><td>库存数量 停售数量</td></tr><tr><td colspan="3">仓库：贵州火石坡库</td><td></td></tr><tr><td colspan="3">厂牌：葵花得菲尔</td><td></td></tr><tr><td colspan="3">《</td><td></td></tr><tr><td colspan="3">阿莫西林克拉维酸钾颗粒</td><td></td></tr><tr><td colspan="3">商品编码：40010100270504</td><td></td></tr><tr><td colspan="3">失效日期：2025-09-30</td><td></td></tr><tr><td colspan="3">仓库：贵州火石坡库</td><td></td></tr><tr><td colspan="3"></td><td></td></tr><tr><td colspan="3">厂牌：葵花得菲尔</td><td></td></tr><tr><td colspan="3">《</td><td></td></tr><tr><td colspan="3"></td><td></td></tr><tr><td colspan="3"></td><td></td></tr><tr><td colspan="3"></td><td></td></tr></table></body></html>