附件

# “重药好青年 推荐表

<html><body><table><tr><td>姓名</td><td></td><td>性别</td><td></td><td rowspan="3">1寸 照片</td></tr><tr><td>出生年月</td><td></td><td>民族</td><td></td></tr><tr><td>籍贯</td><td></td><td>文化程度</td><td></td></tr><tr><td>手机号码</td><td></td><td>单位职务</td><td colspan="2"></td></tr><tr><td colspan="2">申报类别</td><td colspan="3"></td></tr><tr><td>个人 简历</td><td></td><td></td><td></td></tr><tr><td>曾获 主要 奖励</td><td></td><td></td><td></td></tr></table></body></html>

<html><body><table><tr><td>简要 事迹</td><td>(100至200字)</td></tr><tr><td rowspan="2">主要 事迹</td><td>(1500字左右，可另附页)</td></tr><tr><td></td></tr></table></body></html>

<html><body><table><tr><td>团组织 意见</td><td>（盖章） 年月日</td></tr><tr><td>党组织 意见</td><td>(盖章) 年月日</td></tr><tr><td>纪检 部门 意见</td><td>（盖章） 年月日</td></tr></table></body></html>

“申报类别”填写（五选一）：爱岗敬业；创新创业；勤学上进；担当奉献；崇德守信。