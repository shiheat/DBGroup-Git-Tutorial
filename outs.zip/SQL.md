
select e.credate 下单时间,o.ordertype 订单类型,d.salesdtlid 销售细单ID, 
       d.salesid 销售总单ID, ab.customname 客户,ab.mdcode 客户代码,e.targetname 客户地址,bb.goodsname 通用名,b.goodsid 货品ID,bb.goodsunit 基本单位,b.goodsqty 基本单位数量,
       b.unitprice 单价,b.notaxmoney 无税金额,r.companyname 来货单位,bc.factoryname 生产厂家,b.taxrate 税率,to_char(d.stiodate, 'yyyy-mm-dd') 记账日期,ad.entryname 独立单元,ad.zx_financecode 财务编码,
       m.arrivaldate 到货日期,a.certid 传票ID,d.costingprice 成本单价,d.costingprice*b.goodsqty 成本金额,a.invno 发票号,
       a.invcode 发票代码,a.zx_tickdate 发票日期,d.stiodate 出库日期
  from bms_sa_settle_doc  a,
       pub_customer       ab,
       pub_employee       ac,
       pub_entry          ad,
       pub_formoney       ae,
       pub_employee       af,
       pub_employee       ai,
       bms_agent_def      aj,
       bms_contact_def    ak,
       bms_sa_settle_dtl  b,
       pub_employee       am,
       pub_goods          bb,
       pub_factory        bc,
       pub_employee       bd,
       pub_company        be,
       pub_employee       bf,
       bms_sa_doctoset      c,
       bms_sa_dtl           d,
       bms_sa_doc           e,
       pub_custom_class_dtl cl, 
     tozw_account_doc g,
     tozw_account_doc f,
     bms_st_io_dtl m,
     zx_saleordertype o,
     bms_lot_def p, 
     bms_batch_def q, 
     pub_company r, 
     bms_contact_def s 
     , pub_entry_goods t 
     , zx_custom_to_explain zcte 
     , pub_company fldw 
     , zx_bms_sa_dtl_behalf p 
     , bms_cert_doc w 
     ,cqyyprod.zx_bms_sadtl_acctype acc
     ,zx_bms_settledtl_acctype acd 
     ,zx_creditacctype ace 
     ,zx_creditacctype acf, 
     zx_bms_business_code zc, 
     pub_entry_customer mn 
     ,bms_st_def bsd 
      ,(select dd.settletype,dd.settletypeid from pub_settletype_ddl dd where nvl(dd.useforsal, 0) = 1) psd   
      ,pub_employee pe
      ,zx_outsystom os                        
      ,(select contactid,
                       companyid,
                       entryid,
                       zx_cusdept
                  from pub_company_to_contact
                 where nvl(type, 0) = 2) pctc 
      ,bms_lot_def def 
 where a.sasettleid = b.sasettleid
   and a.customid = ab.customid(+)
   and a.inputmanid = ac.employeeid(+)
   and a.entryid = ad.entryid(+)
   and a.fmid = ae.fmid(+)
   and a.confirmmanid = af.employeeid(+)
   and a.printmanid = ai.employeeid(+)
   and a.agentid = aj.agentid(+)
   and a.contactid = ak.contactid(+)
   and a.zx_gtaxtickmanid = am.employeeid(+)
   and b.goodsid = bb.goodsid(+)
   and bb.factoryid = bc.factoryid(+)
   and b.salerid = bd.employeeid(+)
   and b.salesdeptid = be.companyid(+)
   and b.invalidmanid = bf.employeeid(+)
   and b.sasettledtlid = c.sasettledtlid(+)
   and c.salesdtlid = d.salesdtlid(+)
   and d.salesid = e.salesid(+)
   and a.customid = cl.customid(+) 
   and cl.classtypeid(+) = 4 
   and a.certid=g.certid(+)
   and g.usestatus(+) = 0
   and f.usestatus(+) = 0
   and b.skcertid=f.certid(+)
   and b.iodtlid = m.iodtlid(+)
   and e.ordertypeid = o.id(+)
   and b.lotid = p.lotid(+)
   and b.batchid = q.batchid(+)
   and q.companyid = r.companyid(+)
   and q.contactid = s.contactid(+) 
   and b.goodsid = t.goodsid(+)
   and a.entryid = t.entryid 
   and e.explainid = zcte.explainid(+)
   and d.zx_companyid = fldw.companyid(+)
   and d.salesdtlid = p.salesdtlid(+)
   and a.certid = w.certid(+)
   and d.salesdtlid = acc.salesdtlid(+)
   and b.sasettledtlid = acd.sasettledtlid(+)
   and acc.acctypeid = ace.acctypeid(+)
   and acd.acctypeid = acf.acctypeid(+)
   and e.zx_code_id = zc.zx_code_id(+)
   and a.customid = mn.customid(+)
   and a.entryid = mn.entryid(+)
   and d.storageid = bsd.storageid(+)
   and b.settletypeid=psd.settletypeid(+)
   and d.zx_supplyerid=pe.employeeid(+)
   and a.contactid = pctc.contactid(+)
   and a.customid = pctc.companyid(+)
   and a.entryid = pctc.entryid(+) 
   and e.zx_outsyscode = os.outsyscode(+)
   and e.entryid = os.entryid(+)
   and d.lotid = def.lotid(+)
and b.sasettledtlid not in (select sasettledtlid from bms_sa_settle_dtl where nvl(zx_diffhandle,0)<>0)
and to_char(g.tozwdate,'yyyymmdd')>={日期} and to_char(g.tozwdate,'yyyymmdd')<={日期}
and a.entryid in {独立单元}
