<html><body><table><tr><td>项目名称：中台ERP改造</td><td>方案节点：4.5.2 流程名称：ERP关联交易退货</td><td>流程说明：ERP发起的关联交易退货 处理流程</td></tr></table></body></html>

![](images/560fde730e97191e671fdcc6df4f65021dfe74317329b320cb1bf4f8a5292893.jpg)