# 重庆医药扫码 （含器械UDI） 规则上线方案

版本：V1.1

2024-06-25

# 文档控制

修改记录  

<html><body><table><tr><td>日期</td><td>作者</td><td>版本</td><td>修改参考</td></tr><tr><td>2024-06-25</td><td>陈少文</td><td>V1.1</td><td>新建</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></table></body></html>

审阅

<html><body><table><tr><td colspan="2">姓名 职位</td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr></table></body></html>

分发

<html><body><table><tr><td>编号</td><td colspan="2">名称 地点</td></tr><tr><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td></tr></table></body></html>

# 目录

档控制. 2  
修改记录.. 2  
审阅... /  
分发... 2  
适用公司范围. 3  
人员配合计划 4  
三、 上线流程. 4

本方案旨在于明确上线期间的工作、顺序及时间安排，在此基础上合理地安排负责人员和时间，保证上线工作的顺利进行，避免出现上线工作失误和各个部门间的脱节混乱。

# 一、适用公司范围

使用主数据系统、批发 ERP、零售 ERP、WMS1.0、WMS2.0、SCM的公司及仓库

# 二、 人员配合计划

1、主数据：李俊涛  
2、批发ERP：刘春燕  
3、零售ERP：余洋

上线方案

4、WMS1.0:缪云涛  
5、WMS2.0:李玉宝  
6、SCM：赵宗新

# 三、上线流程

1、 接集团质量部通知。

2、 主数据系统、批发ERP、零售 ERP、WMS1.0、WMS2.0、SCM发版。

3、 历史数据处理：

1) 主数据系统

带量采购”的选项数据根据规则标记“国家集采”标志（需要集团质量部提供标记规则）。

根据主数据的参数（血液制品、第一类精神药品、第二类精神药品、麻醉药品、药品类易制毒化学品制剂、国家集采（用或的逻辑））在数据库中自动设置所有分子公司“电子监管码扫码标志”为扫码（调整记录不下传）。

提供所有分子公司商品的“电子监管码扫码标志”数据 (EXCEL形式)给到相应分子公司及仓库。

根据分子公司及仓库提供的商品历史数据，主数据系统在数据库中相应调整分子公司“电子监管码扫码标志”、箱序码扫码标志、器械唯一码扫码标志（调整记录不下传）。

提供所有分子公司商品的“电子监管码扫码标志”、箱序码扫码标志、器械唯一码扫码标志数据 (EXCEL形式）给到SCM系统。

2) 批发ERP、零售ERP

根据主数据系统提供电子监管码商品扫码标志数据进行核对并更新补齐。提供电子监管码扫码标志、器械唯一码扫码标志、箱序码扫码标志商品历史数据给主数据系统。

3) WMS1.0、WMS2.0

根据主数据系统提供内部货主电子监管码扫码标志商品数据进行核对并更新补齐。

提供内部货主电子监管码扫码标志、器械唯一码扫码标志、箱序码扫码标志商品历史数据给主数据系统。

# WMS1.0提取 SQL:

selecta.scanflg1,a.scanflg2,a.goodstopcategoryid,

a.goodsid,a.scanflg1 dzjgmbz, case when a.goodstopcategoryid $= " 1 2 "$ and nvl(a.scanflg2,0) $< > 0$ then 1 else O end qxwymbz,

decode(case when a.goodstopcategoryid $= " 1 2 "$ then O else a.scanflg2 end,0,0,1,3,2,1,3,2) xxmbz

from goodsmst a

# WMS2.0提取SQL:

select a.goodsownercode,a.goodsownername,   
t.mdmgoodscode,   
decode(t.ecodeflag,1,1,0) dzjgmbz, --电子监管码扫码标志 decode(t.ecodeflag,2,1,0) qxwymbz, --器械唯一码扫码标志 t.traceabilitycode, --箱序码扫码标志   
t.goodsname,t.goodstype,t.factname   
from tpl_goods t,tpl_goodsowner a   
where t.goodsownerid $\mathbf { \tau } = \mathbf { \tau }$ a.goodsownerid   
and (nvl(t.ecodeflag,0) $> 0$ or nvl(t.traceabilitycode,0) > 0);

提供三方货主电子监管码扫码标志、器械唯一码扫码标志、箱序码扫码标志商品历史数据给SCM系统。

# 4) SCM系统

根据主数据系统提供内部货主电子监管码扫码标志、箱序码扫码标志、器械唯一码扫码标志商品数据，在数据库中更新相应货主的商品数据(调整记录不下传) ）

根据仓库提供的三方货主商品历史数据，在数据库中相应调整相应货主的“电子监管码扫码标志”、箱序码扫码标志、器械唯一码扫码标志(调整记录不下传)

4、 开始使用。